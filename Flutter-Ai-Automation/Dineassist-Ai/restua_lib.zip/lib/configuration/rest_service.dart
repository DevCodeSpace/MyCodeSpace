import 'package:dio/dio.dart';

class RestaurantApiService {
  final Dio dio = Dio();

  Future<Map<String, dynamic>> sendOrder(String order) async {
    final response = await dio.post('https://airesume.app.n8n.cloud/webhook-test/restaurant-order', data: {"order": order});

    final data = response.data;
    print('API response type: ${data.runtimeType}');
    print('API response: $data');
    return (data is List ? data[0] : data) as Map<String, dynamic>;
  }
}
