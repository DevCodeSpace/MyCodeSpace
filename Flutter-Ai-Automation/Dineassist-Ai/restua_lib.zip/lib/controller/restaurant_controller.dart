import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant_order/configuration/rest_service.dart';
import 'package:restaurant_order/model/order_model.dart';
import 'package:speech_to_text/speech_to_text.dart';

class RestaurantController extends GetxController {
  final RestaurantApiService api = RestaurantApiService();

  final SpeechToText speech = SpeechToText();

  TextEditingController orderController = TextEditingController();

  RxBool isListening = false.obs;

  RxBool isLoading = false.obs;

  Rxn<RestaurantOrderModel> orderResult = Rxn<RestaurantOrderModel>();

  @override
  void onInit() {
    super.onInit();
    initSpeech();
  }

  Future<void> initSpeech() async {
    await speech.initialize();
  }

  Future<void> startListening() async {
    isListening.value = true;

    await speech.listen(
      onResult: (result) {
        orderController.text = result.recognizedWords;
      },
    );
  }

  Future<void> stopListening() async {
    await speech.stop();

    isListening.value = false;
  }

  Future<void> sendOrder() async {
    if (orderController.text.isEmpty) {
      return;
    }

    isLoading.value = true;

    try {
      final response = await api.sendOrder(orderController.text);

      orderResult.value = RestaurantOrderModel.fromJson(response);
    } catch (e) {
      print(e.toString());
      Get.snackbar('Error', e.toString());
    }

    isLoading.value = false;
  }
}
