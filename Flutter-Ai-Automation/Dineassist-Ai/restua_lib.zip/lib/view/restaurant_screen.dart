import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:restaurant_order/controller/restaurant_controller.dart';

class RestaurantScreen extends StatelessWidget {
  RestaurantScreen({super.key});

  final RestaurantController controller = Get.put(RestaurantController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Restaurant')),

      body: Padding(
        padding: const EdgeInsets.all(16),

        child: Column(
          children: [
            TextField(
              controller: controller.orderController,

              decoration: const InputDecoration(hintText: 'Enter food order', border: OutlineInputBorder()),
            ),

            const SizedBox(height: 16),

            Obx(() {
              return GestureDetector(
                onTap: () async {
                  if (controller.isListening.value) {
                    await controller.stopListening();
                  } else {
                    await controller.startListening();
                  }
                },

                child: CircleAvatar(
                  radius: 35,

                  backgroundColor: controller.isListening.value ? Colors.red : Colors.green,

                  child: Icon(controller.isListening.value ? Icons.mic : Icons.mic_none, color: Colors.white, size: 35),
                ),
              );
            }),

            ElevatedButton(onPressed: controller.sendOrder, child: const Text('Place Order')),

            const SizedBox(height: 20),

            Obx(() {
              if (controller.isLoading.value) {
                return const CircularProgressIndicator();
              }

              final result = controller.orderResult.value;

              if (result == null) {
                return const SizedBox();
              }

              return Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    const Text('Ordered Items', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),

                    const SizedBox(height: 10),

                    Expanded(
                      child: ListView.builder(
                        itemCount: result.items.length,

                        itemBuilder: (context, index) {
                          final item = result.items[index];

                          return Card(
                            child: ListTile(title: Text(item.name), subtitle: Text('Qty: ${item.quantity}'), trailing: Text('₹${item.price}')),
                          );
                        },
                      ),
                    ),

                    const SizedBox(height: 10),

                    Text('Total: ₹${result.total}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),

                    const SizedBox(height: 10),

                    Container(
                      padding: const EdgeInsets.all(12),

                      decoration: BoxDecoration(color: Colors.orange.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),

                      child: Text(result.suggestion),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
