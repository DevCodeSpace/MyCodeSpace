// lib/app/models/employee_model.dart
//
// In a real app, this data comes from your backend.
// faceId is set AFTER first liveness scan (isFaceIdNew == true).

class EmployeeModel {
  final String id;
  final String name;
  final String department;
  final String designation;
  String? faceId; // null until enrolled via liveness

  EmployeeModel({required this.id, required this.name, required this.department, required this.designation, this.faceId});

  String get initials => name.split(' ').map((e) => e[0]).take(2).join().toUpperCase();

  bool get isEnrolled => faceId != null;

  static List<EmployeeModel> get demoList => [
    EmployeeModel(id: 'EMP001', name: 'Rahul Sharma', department: 'Engineering', designation: 'Flutter Dev'),
    EmployeeModel(id: 'EMP002', name: 'Priya Patel', department: 'Design', designation: 'UI/UX Designer'),
    EmployeeModel(id: 'EMP003', name: 'Amit Verma', department: 'Marketing', designation: 'Manager'),
    EmployeeModel(id: 'EMP004', name: 'Sneha Joshi', department: 'HR', designation: 'HR Executive'),
    EmployeeModel(id: 'EMP005', name: 'Karan Mehta', department: 'Finance', designation: 'Finance Analyst'),
  ];
}
