// lib/app/modules/attendance/attendance_controller.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../models/attendance_model.dart';
import '../../models/employee_model.dart';
import '../../routes/app_routes.dart';

enum ScanPurpose { enroll, checkIn, checkOut }

class AttendanceController extends GetxController {
  // ── Data ───────────────────────────────────────────────────
  final employees = EmployeeModel.demoList.obs;
  final records = <AttendanceRecord>[].obs;

  // faceId → employeeId  (in-memory registry; use SharedPrefs/DB in prod)
  final Map<String, String> _faceIdRegistry = {};

  // Track today's check-in/out per employee
  final checkedInIds = <String>{}.obs;
  final checkedOutIds = <String>{}.obs;

  // Current scan context (set before navigating to liveness screen)
  final Rxn<EmployeeModel> pendingEmployee = Rxn();
  final Rx<ScanPurpose> pendingPurpose = ScanPurpose.enroll.obs;

  // ── Filter State ──────────────────────────────────────────
  final searchQuery = ''.obs;
  final selectedStatus = Rxn<AttendanceStatus>();
  final selectedDepartment = ''.obs;
  final minConfidence = 0.0.obs;
  final sortBy = 'newest'.obs;

  // ── Employee Filter State ─────────────────────────────────
  final employeeSearchQuery = ''.obs;
  final selectedEmployeeDepartment = ''.obs;

  // ── Computed ───────────────────────────────────────────────
  int get presentCount => checkedInIds.length;
  int get absentCount => employees.length - checkedInIds.length;
  int get lateCount => records.where((r) => r.status == AttendanceStatus.late).length;

  bool get isFilterActive => searchQuery.isNotEmpty || selectedStatus.value != null || selectedDepartment.isNotEmpty || minConfidence.value > 0.0 || sortBy.value != 'newest';

  List<AttendanceRecord> get filteredRecords {
    final query = searchQuery.value.trim().toLowerCase();
    final status = selectedStatus.value;
    final dept = selectedDepartment.value.trim().toLowerCase();
    final minConf = minConfidence.value;

    var list = records.where((r) {
      final matchesSearch = query.isEmpty || r.employeeName.toLowerCase().contains(query) || r.department.toLowerCase().contains(query);
      final matchesStatus = status == null || r.status == status;
      final matchesDept = dept.isEmpty || r.department.toLowerCase() == dept;
      final matchesConfidence = (r.confidenceScore * 100) >= minConf;
      return matchesSearch && matchesStatus && matchesDept && matchesConfidence;
    }).toList();

    if (sortBy.value == 'newest') {
      list.sort((a, b) => b.checkInTime.compareTo(a.checkInTime));
    } else if (sortBy.value == 'oldest') {
      list.sort((a, b) => a.checkInTime.compareTo(b.checkInTime));
    } else if (sortBy.value == 'confidence') {
      list.sort((a, b) => b.confidenceScore.compareTo(a.confidenceScore));
    }

    return list;
  }

  void resetFilters() {
    searchQuery.value = '';
    selectedStatus.value = null;
    selectedDepartment.value = '';
    minConfidence.value = 0.0;
    sortBy.value = 'newest';
  }

  void seedDemoRecords() {
    if (records.isNotEmpty) return;

    final now = DateTime.now();

    // 1. Rahul Sharma (EMP001) - Present (On Time check in at 09:05 AM)
    final checkInRahul = DateTime(now.year, now.month, now.day, 9, 5);
    records.add(
      AttendanceRecord(
        id: 'REC_EMP001',
        faceId: 'FID_EMP001_DEMO_SECURE',
        employeeName: 'Rahul Sharma',
        department: 'Engineering',
        checkInTime: checkInRahul,
        confidenceScore: 0.98,
        status: AttendanceStatus.present,
      ),
    );
    checkedInIds.add('EMP001');

    // 2. Priya Patel (EMP002) - Late (Checked in at 09:42 AM)
    final checkInPriya = DateTime(now.year, now.month, now.day, 9, 42);
    records.add(
      AttendanceRecord(
        id: 'REC_EMP002',
        faceId: 'FID_EMP002_DEMO_SECURE',
        employeeName: 'Priya Patel',
        department: 'Design',
        checkInTime: checkInPriya,
        confidenceScore: 0.95,
        status: AttendanceStatus.late,
      ),
    );
    checkedInIds.add('EMP002');

    // 3. Amit Verma (EMP003) - Checked Out (Check in at 08:58 AM, Check out at 05:30 PM)
    final checkInAmit = DateTime(now.year, now.month, now.day, 8, 58);
    final checkOutAmit = DateTime(now.year, now.month, now.day, 17, 30);
    records.add(
      AttendanceRecord(
        id: 'REC_EMP003',
        faceId: 'FID_EMP003_DEMO_SECURE',
        employeeName: 'Amit Verma',
        department: 'Marketing',
        checkInTime: checkInAmit,
        checkOutTime: checkOutAmit,
        confidenceScore: 0.92,
        status: AttendanceStatus.checkedOut,
      ),
    );
    checkedInIds.add('EMP003');
    checkedOutIds.add('EMP003');

    // 4. Sneha Joshi (EMP004) - Checked Out (Check in at 09:12 AM, Check out at 05:00 PM)
    final checkInSneha = DateTime(now.year, now.month, now.day, 9, 12);
    final checkOutSneha = DateTime(now.year, now.month, now.day, 17, 0);
    records.add(
      AttendanceRecord(
        id: 'REC_EMP004',
        faceId: 'FID_EMP004_DEMO_SECURE',
        employeeName: 'Sneha Joshi',
        department: 'HR',
        checkInTime: checkInSneha,
        checkOutTime: checkOutSneha,
        confidenceScore: 0.97,
        status: AttendanceStatus.checkedOut,
      ),
    );
    checkedInIds.add('EMP004');
    checkedOutIds.add('EMP004');

    // Sort initially by newest
    records.sort((a, b) => b.checkInTime.compareTo(a.checkInTime));
  }

  bool isCheckedIn(String empId) => checkedInIds.contains(empId);
  bool isCheckedOut(String empId) => checkedOutIds.contains(empId);

  EmployeeModel? employeeByFaceId(String faceId) {
    final empId = _faceIdRegistry[faceId];
    if (empId == null) return null;
    return employees.firstWhereOrNull((e) => e.id == empId);
  }

  String get todayLabel {
    final now = DateTime.now();
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${now.day} ${m[now.month - 1]} ${now.year}';
  }

  // ── Employee Management & CRUD ────────────────────────────
  List<EmployeeModel> get filteredEmployees {
    final query = employeeSearchQuery.value.trim().toLowerCase();
    final dept = selectedEmployeeDepartment.value.trim().toLowerCase();

    return employees.where((emp) {
      final matchesSearch = query.isEmpty || emp.name.toLowerCase().contains(query) || emp.designation.toLowerCase().contains(query) || emp.id.toLowerCase().contains(query);
      final matchesDept = dept.isEmpty || emp.department.toLowerCase() == dept;
      return matchesSearch && matchesDept;
    }).toList();
  }

  void addEmployee({required String name, required String department, required String designation}) {
    int nextNum = employees.length + 1;
    String id = 'EMP${nextNum.toString().padLeft(3, '0')}';
    while (employees.any((e) => e.id == id)) {
      nextNum++;
      id = 'EMP${nextNum.toString().padLeft(3, '0')}';
    }

    final newEmp = EmployeeModel(id: id, name: name, department: department, designation: designation);

    employees.add(newEmp);
    employees.refresh();
    Get.back();
    _snack('🎉 Employee Added!', '$name has been registered under $department.', Colors.green);
  }

  void updateEmployee(String id, {required String name, required String department, required String designation}) {
    final idx = employees.indexWhere((e) => e.id == id);
    if (idx == -1) return;

    final existingFaceId = employees[idx].faceId;
    employees[idx] = EmployeeModel(id: id, name: name, department: department, designation: designation, faceId: existingFaceId);
    employees.refresh();

    for (var i = 0; i < records.length; i++) {
      if (records[i].id.startsWith(id) || records[i].faceId == existingFaceId) {
        records[i] = AttendanceRecord(
          id: records[i].id,
          faceId: records[i].faceId,
          employeeName: name,
          department: department,
          checkInTime: records[i].checkInTime,
          checkOutTime: records[i].checkOutTime,
          status: records[i].status,
          confidenceScore: records[i].confidenceScore,
        );
      }
    }
    records.refresh();
    Get.back();
    _snack('📝 Employee Updated', '$name details have been successfully modified.', Colors.blue);
  }

  void deleteEmployee(String id) {
    final emp = employees.firstWhereOrNull((e) => e.id == id);
    if (emp == null) return;

    employees.removeWhere((e) => e.id == id);
    if (emp.faceId != null) {
      _faceIdRegistry.remove(emp.faceId);
    }
    checkedInIds.remove(id);
    checkedOutIds.remove(id);
    employees.refresh();
    Get.back();
    _snack('🗑️ Employee Removed', '${emp.name} has been removed from Smart Attend.', Colors.red);
  }

  void resetFaceId(String id) {
    final emp = employees.firstWhereOrNull((e) => e.id == id);
    if (emp == null) return;

    final oldFaceId = emp.faceId;
    emp.faceId = null;
    if (oldFaceId != null) {
      _faceIdRegistry.remove(oldFaceId);
    }
    checkedInIds.remove(id);
    checkedOutIds.remove(id);
    records.removeWhere((r) => r.employeeName == emp.name);
    employees.refresh();
    records.refresh();

    _snack('🔑 Biometrics Reset', 'Face ID cleared. ${emp.name} requires re-enrollment.', Colors.orange);
  }

  // ── Navigate to Liveness ──────────────────────────────────
  void openEnroll(EmployeeModel emp) {
    if (emp.isEnrolled) {
      _snack('Already Enrolled', '${emp.name} is already registered.', Colors.orange);
      return;
    }
    pendingEmployee.value = emp;
    pendingPurpose.value = ScanPurpose.enroll;
    pendingEmployee.refresh();
    Get.toNamed(AppRoutes.liveness);
  }

  void openCheckIn(EmployeeModel emp) {
    if (!emp.isEnrolled) {
      _snack('Not Enrolled', 'Please enroll ${emp.name} first.', Colors.orange);
      return;
    }
    if (isCheckedIn(emp.id)) {
      _snack('Already Checked In', '${emp.name} is already present today.', Colors.orange);
      return;
    }
    pendingEmployee.value = emp;

    pendingPurpose.value = ScanPurpose.checkIn;
    pendingEmployee.refresh();
    Get.toNamed(AppRoutes.liveness);
  }

  void openCheckOut(EmployeeModel emp) {
    if (!isCheckedIn(emp.id)) {
      _snack('Not Checked In', '${emp.name} has not checked in today.', Colors.orange);
      return;
    }
    if (isCheckedOut(emp.id)) {
      _snack('Already Checked Out', '${emp.name} has already checked out.', Colors.orange);
      return;
    }
    pendingEmployee.value = emp;
    pendingPurpose.value = ScanPurpose.checkOut;
    pendingEmployee.refresh();
    Get.toNamed(AppRoutes.liveness);
  }

  // ── Callbacks from LivenessView ───────────────────────────

  /// Called when flutter_face_liveness returns onSuccess
  void onLivenessSuccess({required String faceId, required bool isFaceIdNew, required double confidenceScore, required String sessionId}) {
    Get.back(); // close liveness screen

    final emp = pendingEmployee.value;
    if (emp == null) return;

    switch (pendingPurpose.value) {
      case ScanPurpose.enroll:
        // Save faceId → empId mapping
        emp.faceId = faceId;
        _faceIdRegistry[faceId] = emp.id;
        employees.refresh();
        _snack('✅ Enrolled!', '${emp.name} face registered. Face ID: ${faceId.substring(0, 12)}…', Colors.green);
        break;

      case ScanPurpose.checkIn:
        // Verify the returned faceId matches enrolled faceId
        if (faceId != emp.faceId && !isFaceIdNew) {
          // Different face scanned
          _snack('❌ Face Mismatch', 'Scanned face does not match ${emp.name}.', Colors.red);
          break;
        }
        _recordCheckIn(emp, faceId, confidenceScore);
        break;

      case ScanPurpose.checkOut:
        if (faceId != emp.faceId && !isFaceIdNew) {
          _snack('❌ Face Mismatch', 'Scanned face does not match ${emp.name}.', Colors.red);
          break;
        }
        _recordCheckOut(emp);
        break;
    }

    pendingEmployee.value = null;
  }

  void onLivenessFailed(String reason) {
    Get.back();
    _snack('Verification Failed', reason, Colors.red);
    pendingEmployee.value = null;
  }

  // ── Private helpers ───────────────────────────────────────

  void _recordCheckIn(EmployeeModel emp, String faceId, double score) {
    final now = DateTime.now();
    final isLate = now.hour > 9 || (now.hour == 9 && now.minute > 30);

    records.add(
      AttendanceRecord(
        id: '${emp.id}_${now.millisecondsSinceEpoch}',
        faceId: faceId,
        employeeName: emp.name,
        department: emp.department,
        checkInTime: now,
        confidenceScore: score,
        status: isLate ? AttendanceStatus.late : AttendanceStatus.present,
      ),
    );

    checkedInIds.add(emp.id);

    _snack(
      '✅ Check-In Success!',
      '${emp.name} · ${_fmt(now)}${isLate ? ' (Late)' : ' (On Time)'}  •  ${(score * 100).toStringAsFixed(0)}% confidence',
      isLate ? Colors.orange : Colors.green,
    );
  }

  void _recordCheckOut(EmployeeModel emp) {
    final idx = records.indexWhere((r) => r.employeeName == emp.name && r.checkOutTime == null);
    if (idx == -1) return;

    final now = DateTime.now();
    records[idx].checkOutTime = now;
    records[idx].status = AttendanceStatus.checkedOut;
    records.refresh();
    checkedOutIds.add(emp.id);

    _snack('👋 Check-Out!', '${emp.name} · ${_fmt(now)}  •  Duration: ${records[idx].duration}', Colors.blue);
  }

  String _fmt(DateTime dt) => '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';

  void _snack(String title, String msg, Color color) {
    Get.snackbar(
      title,
      msg,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: color.withValues(alpha: 0.12),
      colorText: color,
      margin: const EdgeInsets.all(12),
      borderRadius: 12,
      duration: const Duration(seconds: 4),
    );
  }
}
