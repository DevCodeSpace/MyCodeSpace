// lib/app/modules/attendance/home_view.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../models/employee_model.dart';
import '../../routes/app_routes.dart';
import 'attendance_controller.dart';

class HomeView extends GetView<AttendanceController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // ── Beautiful Premium Header Sliver ─────────────────────────────
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            stretch: true,
            backgroundColor: const Color(0xFF020C1E),
            elevation: 0,
            actions: [
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: _HeaderEmployeeButton(onTap: () => Get.toNamed(AppRoutes.employee)),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 12, top: 10),
                child: _HeaderHistoryButton(onTap: () => Get.toNamed(AppRoutes.history)),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              expandedTitleScale: 1.2,
              centerTitle: false,
              titlePadding: const EdgeInsetsDirectional.only(start: 20, bottom: 14),
              title: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.corporate_fare_rounded, color: Color(0xFF00BCD4), size: 18),
                  SizedBox(width: 6),
                  Text(
                    'Team Dashboard',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 0.5),
                  ),
                ],
              ),
              stretchModes: const [StretchMode.zoomBackground],
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Ocean Deep gradient
                  Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF004D60), Color(0xFF00303D), Color(0xFF071828), Color(0xFF020C1E)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        stops: [0.0, 0.35, 0.68, 1.0],
                      ),
                    ),
                  ),
                  // Top-right teal orb
                  Positioned(
                    top: -55,
                    right: -35,
                    child: Container(
                      width: 230,
                      height: 230,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [const Color(0xFF00BCD4).withValues(alpha: 0.28), Colors.transparent]),
                      ),
                    ),
                  ),
                  // Bottom-left ocean blue orb
                  Positioned(
                    bottom: -40,
                    left: -30,
                    child: Container(
                      width: 180,
                      height: 180,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [const Color(0xFF0077B6).withValues(alpha: 0.25), Colors.transparent]),
                      ),
                    ),
                  ),
                  // Expanded header content
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 50, 20, 68),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Logo row
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(13),
                                gradient: const LinearGradient(colors: [Color(0xFF00BCD4), Color(0xFF0077B6)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                                boxShadow: [BoxShadow(color: const Color(0xFF00BCD4).withValues(alpha: 0.45), blurRadius: 12, offset: const Offset(0, 4))],
                              ),
                              child: const Icon(Icons.corporate_fare_rounded, color: Colors.white, size: 22),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      'NOVA',
                                      style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 2.0, height: 1.0),
                                    ),
                                    SizedBox(width: 5),
                                    Text(
                                      'HQ',
                                      style: TextStyle(color: Color(0xFF00BCD4), fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 2.0, height: 1.0),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 3),
                                Text(
                                  'Attendance Management',
                                  style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 0.5),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const Spacer(),
                        // Date pill — bottom of expanded area, above collapsed title
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: const Color(0xFF00BCD4).withValues(alpha: 0.30)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.today_rounded, color: Color(0xFF00BCD4), size: 13),
                              const SizedBox(width: 7),
                              Text(
                                controller.todayLabel.toUpperCase(),
                                style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.2),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Floating Stats Console Overlay ─────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: _GlassStatsPanel(ctrl: controller),
            ),
          ),

          // ── Quick Filter Legend Chips ────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12),
                  const Text(
                    'TEAM DIRECTORY & STATUS',
                    style: TextStyle(color: Color(0xFF8A99AD), fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: const [
                      _LegendChip('Face Registration Required', Color(0xFF7B61FF), Icons.face),
                      _LegendChip('Checked In', Color(0xFF00C853), Icons.login_rounded),
                      _LegendChip('Checked Out / Exit', Colors.orange, Icons.logout_rounded),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // ── Beautiful Employee Cards List ─────────────────────────────
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (_, i) => _EmployeeCard(emp: controller.employees[i], ctrl: controller),
                childCount: controller.employees.length,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Header Employee Button ────────────────────────────────────────────
class _HeaderEmployeeButton extends StatelessWidget {
  final VoidCallback onTap;
  const _HeaderEmployeeButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        child: const Icon(Icons.badge_rounded, color: Color(0xFF00E5FF), size: 25),
      ),
    );
  }
}

// ── Header History Button ─────────────────────────────────────────────
class _HeaderHistoryButton extends StatelessWidget {
  final VoidCallback onTap;
  const _HeaderHistoryButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        // decoration: BoxDecoration(
        //   color: Colors.white.withValues(alpha: 0.08),
        //   borderRadius: BorderRadius.circular(10),
        //   border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
        // ),
        child: const Icon(Icons.history_rounded, color: Colors.white, size: 25),
      ),
    );
  }
}

// ── Glassmorphic Stats Panel ──────────────────────────────────────────
class _GlassStatsPanel extends StatelessWidget {
  final AttendanceController ctrl;
  const _GlassStatsPanel({required this.ctrl});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: const Color(0xFF0F1423).withValues(alpha: 0.06), blurRadius: 20, offset: const Offset(0, 8))],
        border: Border.all(color: Colors.white),
      ),
      child: Obx(
        () => IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(child: _StatBox('Present', ctrl.presentCount, const Color(0xFF00C853), Icons.check_circle_outline)),
              _VerticalDivider(),
              Expanded(child: _StatBox('Absent', ctrl.absentCount, const Color(0xFFFF3D00), Icons.cancel_outlined)),
              _VerticalDivider(),
              Expanded(child: _StatBox('Late', ctrl.lateCount, const Color(0xFFFFB300), Icons.alarm_outlined)),
            ],
          ),
        ),
      ),
    );
  }
}

class _VerticalDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(width: 1, color: const Color(0xFFE2E8F0));
  }
}

class _StatBox extends StatelessWidget {
  final String label;
  final int value;
  final Color color;
  final IconData icon;

  const _StatBox(this.label, this.value, this.color, this.icon);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 4),
            Text(
              '$value',
              style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 22, height: 1.0),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          label.toUpperCase(),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Color(0xFF8A99AD), fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.0),
        ),
      ],
    );
  }
}

class _LegendChip extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;

  const _LegendChip(this.label, this.color, this.icon);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: 0.18)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

// ── Employee Card ─────────────────────────────────────────────────────
class _EmployeeCard extends StatelessWidget {
  final EmployeeModel emp;
  final AttendanceController ctrl;
  const _EmployeeCard({required this.emp, required this.ctrl});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final isIn = ctrl.isCheckedIn(emp.id);
      final isOut = ctrl.isCheckedOut(emp.id);
      final enrolled = emp.isEnrolled;

      // Access observable to trigger rebuild on employee update
      ctrl.employees.length;

      // Determine colors and states
      Color ringColor = Colors.grey.shade300;

      if (enrolled) {
        if (isIn) {
          ringColor = isOut ? Colors.orange : const Color(0xFF00C853);
        } else {
          ringColor = const Color(0xFF7B61FF);
        }
      }

      return Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: const Color(0xFF0F1423).withValues(alpha: 0.03), blurRadius: 10, offset: const Offset(0, 4))],
          border: Border.all(color: const Color(0xFFECEFF5)),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    // Avatar with glowing status ring
                    _CustomAvatarRing(
                      color: ringColor,
                      pulse: false,
                      child: CircleAvatar(
                        radius: 26,
                        backgroundColor: _deptColor(emp.department).withValues(alpha: 0.08),
                        child: Text(
                          emp.initials,
                          style: TextStyle(color: _deptColor(emp.department), fontWeight: FontWeight.w900, fontSize: 16),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),

                    // Info Column
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  emp.name,
                                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Color(0xFF1E293B)),
                                ),
                              ),
                              // Subtly colored Department tag
                              _DeptTag(dept: emp.department, color: _deptColor(emp.department)),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            emp.designation,
                            style: const TextStyle(color: Color(0xFF8A99AD), fontSize: 12, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 8),

                          // Dynamic Enrollment + Status Pill Badges
                          Row(
                            children: [
                              _StatusBadge(
                                label: enrolled ? 'Registered' : 'Not Registered',
                                color: enrolled ? const Color(0xFF00897B) : const Color(0xFF78909C),
                                icon: enrolled ? Icons.verified_user : Icons.no_accounts,
                              ),
                              if (isIn) ...[
                                const SizedBox(width: 6),
                                _StatusBadge(
                                  label: isOut ? 'Checked Out' : 'Present',
                                  color: isOut ? Colors.blue : const Color(0xFF00C853),
                                  icon: isOut ? Icons.exit_to_app : Icons.check_circle_outline,
                                ),
                              ],
                              if (isIn && !isOut) ...[const SizedBox(width: 6), const _AnimatedWorkingIcon()],
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                const Divider(color: Color(0xFFF1F5F9), height: 1),
                const SizedBox(height: 12),

                // Premium tactile Action Buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (!enrolled)
                      _TactileBtn(
                        label: 'Enroll Face',
                        icon: Icons.face_retouching_natural,
                        color: const Color(0xFF7B61FF),
                        onTap: () {
                          ctrl.openEnroll(emp);
                        },
                      ),
                    if (enrolled && !isIn)
                      _TactileBtn(
                        label: 'Check In',
                        icon: Icons.login_rounded,
                        color: const Color(0xFF00E5FF),
                        textColor: const Color(0xFF0F1423),
                        onTap: () => ctrl.openCheckIn(emp),
                      ),
                    if (isIn && !isOut) _TactileBtn(label: 'Check Out', icon: Icons.logout_rounded, color: Colors.orange.shade700, onTap: () => ctrl.openCheckOut(emp)),
                    if (isOut)
                      Row(
                        children: const [
                          Icon(Icons.check_circle, color: Color(0xFF00C853), size: 24),
                          SizedBox(width: 6),
                          Text(
                            'Shift Complete',
                            style: TextStyle(color: Color(0xFF00C853), fontWeight: FontWeight.bold, fontSize: 12),
                          ),
                        ],
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  Color _deptColor(String dept) {
    const map = {'Engineering': Color(0xFF1E88E5), 'Design': Color(0xFFD81B60), 'Marketing': Color(0xFFFB8C00), 'HR': Color(0xFF00ACC1), 'Finance': Color(0xFF43A047)};
    return map[dept] ?? Colors.indigo;
  }
}

// ── Custom Pulsing Avatar Ring ────────────────────────────────────────
class _CustomAvatarRing extends StatefulWidget {
  final Color color;
  final bool pulse;
  final Widget child;

  const _CustomAvatarRing({required this.color, required this.pulse, required this.child});

  @override
  State<_CustomAvatarRing> createState() => _CustomAvatarRingState();
}

class _CustomAvatarRingState extends State<_CustomAvatarRing> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(vsync: this, duration: const Duration(seconds: 2));
    if (widget.pulse) {
      _pulseController.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant _CustomAvatarRing oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.pulse && !_pulseController.isAnimating) {
      _pulseController.repeat();
    } else if (!widget.pulse && _pulseController.isAnimating) {
      _pulseController.stop();
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Stack(
          alignment: Alignment.center,
          children: [
            // Pulse circle backdrop
            if (widget.pulse)
              Container(
                width: 62 + (_pulseController.value * 12),
                height: 62 + (_pulseController.value * 12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.color.withValues(alpha: 0.25 * (1.0 - _pulseController.value)),
                ),
              ),

            // Solid outer ring
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: widget.color, width: 2.0),
              ),
              child: widget.child,
            ),
          ],
        );
      },
    );
  }
}

// ── Colored Department Tag ─────────────────────────────────────────────
class _DeptTag extends StatelessWidget {
  final String dept;
  final Color color;
  const _DeptTag({required this.dept, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.06), borderRadius: BorderRadius.circular(8)),
      child: Text(
        dept,
        style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w800),
      ),
    );
  }
}

// ── Minimalist Status Badge ────────────────────────────────────────────
class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;

  const _StatusBadge({required this.label, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.15)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 10),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w800),
          ),
        ],
      ),
    );
  }
}

// ── Animated Working Icon ──────────────────────────────────────────────
class _AnimatedWorkingIcon extends StatefulWidget {
  const _AnimatedWorkingIcon();

  @override
  State<_AnimatedWorkingIcon> createState() => _AnimatedWorkingIconState();
}

class _AnimatedWorkingIconState extends State<_AnimatedWorkingIcon> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _ripple;
  late Animation<double> _rippleOpacity;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat();
    _ripple = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _rippleOpacity = Tween<double>(begin: 0.7, end: 0.0).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF00C853).withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF00C853).withValues(alpha: 0.20)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 14,
            height: 14,
            child: AnimatedBuilder(
              animation: _controller,
              builder: (_, _) => Stack(
                alignment: Alignment.center,
                children: [
                  // ripple ring
                  Container(
                    width: 6 + (_ripple.value * 8),
                    height: 6 + (_ripple.value * 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF00C853).withValues(alpha: _rippleOpacity.value * 0.4),
                    ),
                  ),
                  // solid dot
                  Container(
                    width: 7,
                    height: 7,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF00C853)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 5),
          const Text(
            'Working',
            style: TextStyle(color: Color(0xFF00C853), fontSize: 10, fontWeight: FontWeight.w800),
          ),
        ],
      ),
    );
  }
}

// ── Modern Tactile Action Button ───────────────────────────────────────
class _TactileBtn extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final Color textColor;
  final VoidCallback onTap;

  const _TactileBtn({required this.label, required this.icon, required this.color, this.textColor = Colors.white, required this.onTap});

  @override
  State<_TactileBtn> createState() => _TactileBtnState();
}

class _TactileBtnState extends State<_TactileBtn> with SingleTickerProviderStateMixin {
  double _scale = 1.0;

  void _onTapDown(TapDownDetails details) {
    setState(() => _scale = 0.94);
  }

  void _onTapUp(TapUpDetails details) {
    setState(() => _scale = 1.0);
    widget.onTap();
  }

  void _onTapCancel() {
    setState(() => _scale = 1.0);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _onTapDown,
      onTapUp: _onTapUp,
      onTapCancel: _onTapCancel,
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 100),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: widget.color,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [BoxShadow(color: widget.color.withValues(alpha: 0.24), blurRadius: 8, offset: const Offset(0, 3))],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(widget.icon, color: widget.textColor, size: 14),
              const SizedBox(width: 6),
              Text(
                widget.label,
                style: TextStyle(color: widget.textColor, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.2),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
