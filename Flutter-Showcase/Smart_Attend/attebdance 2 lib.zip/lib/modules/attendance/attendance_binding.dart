// lib/app/modules/attendance/attendance_binding.dart

import 'package:get/get.dart';
import 'attendance_controller.dart';

class AttendanceBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AttendanceController>(() => AttendanceController(), fenix: true);
  }
}
