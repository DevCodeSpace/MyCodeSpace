// lib/app/modules/attendance/liveness_view.dart

import 'package:flutter/material.dart';
import 'package:flutter_face_liveness/flutter_face_liveness.dart';
import 'package:get/get.dart';
import 'attendance_controller.dart';

class LivenessView extends StatefulWidget {
  const LivenessView({super.key});

  @override
  State<LivenessView> createState() => _LivenessViewState();
}

class _LivenessViewState extends State<LivenessView> {
  // ── Changing this key forces FlutterFaceLiveness to fully
  //    dispose + recreate → new internal session ID generated
  Key _livenessKey = UniqueKey();
  bool _isRetrying = false;

  void _retry() {
    setState(() {
      _livenessKey = UniqueKey(); // ← fresh session
      _isRetrying = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = Get.find<AttendanceController>();

    return Obx(() {
      final emp = ctrl.pendingEmployee.value;
      final purpose = ctrl.pendingPurpose.value;

      final actions = switch (purpose) {
        ScanPurpose.enroll => [LivenessAction.blink, LivenessAction.turnLeft, LivenessAction.smile],
        ScanPurpose.checkIn => [LivenessAction.blink, LivenessAction.turnLeft],
        ScanPurpose.checkOut => [LivenessAction.blink],
      };

      final title = switch (purpose) {
        ScanPurpose.enroll => 'Enroll Face',
        ScanPurpose.checkIn => 'Check In',
        ScanPurpose.checkOut => 'Check Out',
      };

      return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
              if (emp != null) Text(emp.name, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
          leading: IconButton(icon: const Icon(Icons.close), onPressed: () => ctrl.onLivenessFailed('Cancelled by user')),
        ),
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.black,

        body: _isRetrying
            // ── Brief loading state while key resets ────────
            ? const Center(child: CircularProgressIndicator(color: Colors.white))
            // ── Fresh FlutterFaceLiveness per UniqueKey ─────
            : FlutterFaceLiveness(
                key: _livenessKey, // ← THE FIX
                actions: actions,
                config: LivenessConfig(
                  randomizeActions: true,
                  enableAntiSpoof: true,
                  enableFaceId: true,
                  faceIdSimilarityThreshold: 0.68,
                  sessionTimeoutMs: 60000,
                  themeMode: ThemeMode.system,
                ),

                // ✅ SUCCESS
                onSuccess: (LivenessResult result) {
                  ctrl.onLivenessSuccess(
                    faceId: result.faceId ?? 'UNKNOWN',
                    isFaceIdNew: result.isFaceIdNew ?? true,
                    confidenceScore: result.confidenceScore,
                    sessionId: result.sessionId ?? 'UNKNOWN',
                  );
                },

                // ❌ FAILED — show retry dialog instead of auto-close
                onFailed: (String reason) async {
                  // Cancelled → seedha close
                  if (reason == 'Cancelled by user') {
                    ctrl.onLivenessFailed(reason);
                    return;
                  }

                  final shouldRetry = await _showRetryDialog(context, reason);

                  if (shouldRetry == true) {
                    setState(() => _isRetrying = true);
                    // 1 frame baad key reset karo
                    await Future.delayed(const Duration(milliseconds: 100));
                    _retry();
                  } else {
                    ctrl.onLivenessFailed(reason);
                  }
                },
              ),
      );
    });
  }

  Future<bool?> _showRetryDialog(BuildContext context, String reason) {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Liveness Failed'),
        content: Text(reason),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Try Again')),
        ],
      ),
    );
  }
}
